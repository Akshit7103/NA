# Video Analytics System - CCTV Deployment Guide

## 📋 Quick Start for CCTV Deployment

### Step 1: Get Your Camera RTSP URL

First, you need the RTSP URL from your IP camera. Common formats:

```
# Generic Format
rtsp://username:password@camera_ip:port/stream_path

# Examples:
rtsp://admin:admin123@192.168.1.64:554/stream1
rtsp://admin:Password123@10.0.0.50:554/Streaming/Channels/101
```

**How to find your RTSP URL:**

1. **Check camera documentation** or manufacturer website
2. **Common RTSP formats by brand:**

   - **Hikvision**: `rtsp://admin:password@192.168.1.64:554/Streaming/Channels/101`
   - **Dahua**: `rtsp://admin:password@192.168.1.64:554/cam/realmonitor?channel=1&subtype=0`
   - **Uniview**: `rtsp://admin:password@192.168.1.64:554/unicast/c1/s0/live`
   - **Generic/Others**: `rtsp://admin:password@192.168.1.64:554/stream1`

3. **Test the URL with VLC Media Player:**
   - Open VLC
   - Go to Media → Open Network Stream
   - Paste your RTSP URL
   - If video plays, the URL is correct! ✓

### Step 2: Configure the System

Edit `config.yaml` and change the camera source:

```yaml
# Camera Configuration
camera:
  # CHANGE THIS LINE to your RTSP URL:
  source: "rtsp://admin:your_password@192.168.1.64:554/stream1"

  # Keep these settings as default (or adjust if needed)
  reconnect_attempts: 5
  reconnect_delay: 5
  frame_skip: 1  # Set to 2 or 3 if system is slow
```

### Step 3: Install Dependencies

```bash
# Install Python packages
pip install -r requirements.txt
```

### Step 4: Initialize Database

```bash
# Create database and default admin account
python database.py
```

Default login: **admin / admin123** (⚠️ CHANGE THIS IN PRODUCTION!)

### Step 5: Start the System

**Terminal 1 - Web Dashboard:**
```bash
python main.py
```

**Terminal 2 - Detection Engine:**
```bash
python detect.py
```

### Step 6: Access Dashboard

Open browser: `http://localhost:5000` or `http://your_server_ip:5000`

Login with: **admin / admin123**

---

## 🔧 Configuration Options

### Camera Settings

```yaml
camera:
  source: "rtsp://..."  # Your RTSP URL or 0 for webcam
  reconnect_attempts: 5  # How many times to retry connection
  reconnect_delay: 5     # Seconds to wait between retries
  frame_skip: 1          # Process every Nth frame (1=all, 2=half, 3=third)
```

**Performance Tips:**
- **Slow CPU?** Set `frame_skip: 2` or `frame_skip: 3`
- **Fast GPU?** Keep `frame_skip: 1`

### Detection Sensitivity

```yaml
detection:
  person_confidence: 0.5   # Lower = more detections (0.3-0.7 recommended)
  phone_confidence: 0.3    # Lower = more phone detections
  face_similarity: 0.5     # Higher = stricter face matching (0.4-0.6 recommended)
```

**Tuning Tips:**
- **Too many false unauthorized alerts?** Increase `face_similarity` to 0.55 or 0.6
- **Missing people?** Lower `person_confidence` to 0.4
- **Missing phones?** Lower `phone_confidence` to 0.25

### Timing Settings

```yaml
timing:
  log_cooldown: 30              # Seconds between logging same person
  phone_alert_cooldown: 10      # Seconds between phone alerts
  unauthorized_face_grace: 3.0  # Seconds to wait before flagging unknown face
  unauthorized_no_face_grace: 15.0  # Seconds to wait if no face visible
  track_timeout: 5.0            # Seconds before removing lost person
```

---

## 🎥 Testing Your RTSP Connection

### Method 1: VLC Media Player (Recommended)
```
1. Open VLC
2. Media → Open Network Stream
3. Paste RTSP URL
4. If video plays → Connection works! ✓
```

### Method 2: OpenCV Test Script
Create `test_camera.py`:

```python
import cv2

# Replace with your RTSP URL
RTSP_URL = "rtsp://admin:password@192.168.1.64:554/stream1"

cap = cv2.VideoCapture(RTSP_URL)

if not cap.isOpened():
    print("❌ Failed to connect to camera")
else:
    ret, frame = cap.read()
    if ret:
        print("✅ Camera connected successfully!")
        print(f"Resolution: {frame.shape[1]}x{frame.shape[0]}")
    else:
        print("❌ Connected but cannot read frames")

cap.release()
```

Run: `python test_camera.py`

### Method 3: FFmpeg
```bash
ffplay "rtsp://admin:password@192.168.1.64:554/stream1"
```

---

## 🔒 Security Checklist

Before deploying to production:

- [ ] **Change default admin password** (Login → Settings)
- [ ] **Change SECRET_KEY in config.yaml** (generate random string)
- [ ] **Use strong RTSP credentials** (not admin/admin123)
- [ ] **Restrict network access** (firewall rules)
- [ ] **Enable HTTPS** (for production deployment)

---

## 🐛 Troubleshooting

### Problem: "Failed to connect to camera"

**Solutions:**
1. **Test RTSP URL in VLC** first
2. **Check network connectivity** - Can you ping camera IP?
3. **Verify credentials** - Username/password correct?
4. **Check firewall** - Port 554 blocked?
5. **Try different stream path:**
   - `/stream1` → `/stream2`
   - `/h264` → `/h265`
   - Add `/main` or `/sub`

### Problem: "Connected but frames failing"

**Solutions:**
1. **Check camera stream format** (H.264 works best)
2. **Verify network bandwidth** (1080p needs 5-10 Mbps)
3. **Try lower resolution stream** (change to substream)
4. **Check camera settings** (enable RTSP in camera config)

### Problem: "System too slow / low FPS"

**Solutions:**
1. **Increase frame_skip** in config.yaml:
   ```yaml
   frame_skip: 2  # Process every 2nd frame
   ```
2. **Use lower resolution stream** from camera
3. **Use GPU** (install CUDA + cuDNN)
4. **Reduce detection confidence** (fewer boxes to process)
5. **Upgrade hardware** (see requirements)

### Problem: "Too many false unauthorized alerts"

**Solutions:**
1. **Increase face_similarity threshold:**
   ```yaml
   face_similarity: 0.55  # or 0.6
   ```
2. **Increase grace periods:**
   ```yaml
   unauthorized_face_grace: 5.0  # Give more time
   ```
3. **Re-register person with more photos** (10+ instead of 5)
4. **Check lighting** (poor lighting = poor recognition)

### Problem: "Face recognition not working"

**Solutions:**
1. **Check camera angle** (should see face clearly, not top of head)
2. **Improve lighting** (face should be well-lit)
3. **Re-register with better photos** (front-facing, good lighting)
4. **Lower face_similarity threshold:**
   ```yaml
   face_similarity: 0.45  # More lenient
   ```

---

## 📊 Performance Optimization

### For Multiple Cameras:
- Run separate `detect.py` instance for each camera
- Use different config files: `python detect.py --config camera1.yaml`
- Consider dedicated GPU for each 2-3 cameras

### For Low-End Hardware:
```yaml
camera:
  frame_skip: 3  # Process every 3rd frame

detection:
  person_confidence: 0.6  # Fewer detections = faster
```

### For High-End Hardware:
```yaml
camera:
  frame_skip: 1  # Process all frames

detection:
  person_confidence: 0.4  # More sensitive
  phone_confidence: 0.25
```

---

## 🚀 Running as a Service (Auto-start on boot)

### Windows (Task Scheduler):
1. Open Task Scheduler
2. Create Task → "Run at startup"
3. Action: Start Program
4. Program: `C:\Path\To\Python\python.exe`
5. Arguments: `C:\Path\To\Project\main.py`
6. Repeat for `detect.py`

### Linux (systemd):

Create `/etc/systemd/system/video-analytics-web.service`:
```ini
[Unit]
Description=Video Analytics Web Dashboard
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/project
ExecStart=/usr/bin/python3 main.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Create `/etc/systemd/system/video-analytics-detect.service`:
```ini
[Unit]
Description=Video Analytics Detection Engine
After=network.target

[Service]
Type=simple
User=your_user
WorkingDirectory=/path/to/project
ExecStart=/usr/bin/python3 detect.py
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable video-analytics-web
sudo systemctl enable video-analytics-detect
sudo systemctl start video-analytics-web
sudo systemctl start video-analytics-detect
```

---

## 📞 Support

For issues or questions:
1. Check this guide first
2. Test RTSP URL in VLC
3. Check logs for error messages
4. Verify network connectivity

---

## ✅ Pre-Deployment Checklist

Before going to client site:

- [ ] System tested with webcam locally
- [ ] RTSP URL obtained from client/camera vendor
- [ ] Installation USB prepared (Python + dependencies)
- [ ] config.yaml template ready
- [ ] VLC installed for testing
- [ ] Camera credentials documented
- [ ] Network diagram obtained
- [ ] Firewall rules documented
- [ ] Backup plan if network issues
