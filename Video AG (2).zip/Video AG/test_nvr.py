"""
Quick NVR RTSP Connection Test Script
Run this to test if your NVR RTSP URL works before deployment
"""

import cv2
import sys

def test_rtsp(rtsp_url):
    """Test RTSP connection and display video"""
    print(f"\n{'='*60}")
    print("NVR RTSP Connection Test")
    print(f"{'='*60}\n")
    print(f"Testing URL: {rtsp_url}")
    print("\nAttempting to connect...")

    cap = cv2.VideoCapture(rtsp_url)

    if not cap.isOpened():
        print("\n❌ FAILED: Cannot connect to NVR")
        print("\nPossible issues:")
        print("1. Wrong IP address (is NVR on network?)")
        print("2. Wrong username/password")
        print("3. Wrong channel number")
        print("4. RTSP port blocked (554)")
        print("5. Camera/Channel not configured on NVR")
        print("\nTroubleshooting:")
        print("- Ping the NVR: ping <NVR_IP>")
        print("- Check NVR web interface (http://<NVR_IP>)")
        print("- Verify credentials")
        print("- Try sub-stream URL instead of main stream")
        return False

    print("✅ Connected to NVR successfully!\n")
    print("Reading frames...")

    # Try to read a few frames
    success_count = 0
    for i in range(10):
        ret, frame = cap.read()
        if ret:
            success_count += 1
            if i == 0:
                h, w = frame.shape[:2]
                print(f"✅ Frame received: {w}x{h}")

    if success_count >= 5:
        print(f"✅ Successfully read {success_count}/10 frames")
        print("\n🎉 NVR connection working perfectly!")
        print("\nPress 'q' to quit the video window...")

        # Show live video
        while True:
            ret, frame = cap.read()
            if not ret:
                print("⚠️ Lost connection to NVR")
                break

            # Add info overlay
            cv2.putText(frame, "NVR Test - Press 'q' to quit", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

            cv2.imshow("NVR Test", frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cv2.destroyAllWindows()
        print("\n✅ Test completed successfully!")
        print("You can now use this RTSP URL in config.yaml")
        return True
    else:
        print(f"❌ Only read {success_count}/10 frames")
        print("Connection unstable - check network/NVR settings")
        return False

    cap.release()


def print_examples():
    """Print common RTSP URL formats"""
    print("\n" + "="*60)
    print("Common NVR RTSP URL Formats")
    print("="*60 + "\n")

    print("1. HIKVISION NVR:")
    print("   rtsp://admin:password@192.168.1.100:554/Streaming/Channels/101")
    print("   (101=Ch1 main, 102=Ch1 sub, 201=Ch2, etc.)\n")

    print("2. DAHUA NVR:")
    print("   rtsp://admin:password@192.168.1.100:554/cam/realmonitor?channel=1&subtype=0")
    print("   (channel=1,2,3... subtype=0:main, 1:sub)\n")

    print("3. CP PLUS NVR:")
    print("   rtsp://admin:password@192.168.1.100:554/cam/realmonitor?channel=1&subtype=1\n")

    print("4. GENERIC:")
    print("   rtsp://admin:password@192.168.1.100:554/")
    print("   rtsp://admin:password@192.168.1.100:554/stream1\n")

    print("TIP: Use 'sub stream' URLs for better performance!")
    print("     Main stream = 1080p/4MP (slow)")
    print("     Sub stream = 720p/D1 (fast, recommended)")
    print("="*60 + "\n")


if __name__ == "__main__":
    print_examples()

    if len(sys.argv) > 1:
        rtsp_url = sys.argv[1]
    else:
        print("Enter your NVR RTSP URL:")
        print("Example: rtsp://admin:Admin123@192.168.1.100:554/Streaming/Channels/101")
        print("\nRTSP URL: ", end="")
        rtsp_url = input().strip()

    if not rtsp_url:
        print("\n❌ No RTSP URL provided")
        print("\nUsage:")
        print("  python test_nvr.py")
        print("  OR")
        print("  python test_nvr.py rtsp://admin:pass@192.168.1.100:554/Streaming/Channels/101")
        sys.exit(1)

    if not rtsp_url.startswith("rtsp://"):
        print("\n❌ Invalid RTSP URL (must start with rtsp://)")
        sys.exit(1)

    test_rtsp(rtsp_url)
