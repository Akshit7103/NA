# ⚡ Performance Optimization Guide

## 🎯 Quick Performance Settings

### **Scenario 1: Slow CPU (Budget PC)**
**Edit config.yaml:**
```yaml
camera:
  frame_skip: 3  # Process every 3rd frame

detection:
  person_confidence: 0.6
  face_check_interval: 10  # Check face every 10 frames
```
**Expected: 10-15 FPS**

---

### **Scenario 2: Good CPU (Recommended)**
**Edit config.yaml:**
```yaml
camera:
  frame_skip: 2  # Process every 2nd frame

detection:
  person_confidence: 0.5
  face_check_interval: 5  # Check face every 5 frames
```
**Expected: 15-20 FPS**

---

### **Scenario 3: NVIDIA GPU (Best Performance)**
**Edit config.yaml:**
```yaml
camera:
  frame_skip: 1  # Process all frames

detection:
  person_confidence: 0.5
  face_check_interval: 2  # Check face every 2 frames
```

**AND edit detect.py line ~195:**
```python
# Change from:
app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])

# To:
app = FaceAnalysis(name='buffalo_l', providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
```
**Expected: 25-30 FPS**

---

## 📊 Understanding Performance Metrics

### **What is Good Performance?**
- **5-10 FPS**: Acceptable for basic monitoring
- **10-20 FPS**: Good - smooth monitoring
- **20-30 FPS**: Excellent - real-time performance
- **30+ FPS**: Overkill for security (not needed)

### **FPS Display**
The system now shows **FPS counter** in top-left corner of video window.

---

## ⚙️ Configuration Parameters Explained

### **frame_skip**
```yaml
frame_skip: 1  # Process every frame (slowest, most accurate)
frame_skip: 2  # Skip every other frame (2x faster)
frame_skip: 3  # Process every 3rd frame (3x faster)
```

**Impact:**
- Higher = Faster processing
- Trade-off: Slightly slower to detect new people entering

**Recommendation:** Start with 2

---

### **face_check_interval**
```yaml
face_check_interval: 5   # Check face every 5 frames
face_check_interval: 10  # Check face every 10 frames (faster)
face_check_interval: 2   # Check face every 2 frames (more accurate)
```

**Impact:**
- Higher = Faster processing
- Trade-off: Takes slightly longer to identify unknown person

**Recommendation:** 5 for balanced, 10 for speed, 2 for accuracy

---

### **person_confidence**
```yaml
person_confidence: 0.3  # Detect more people (slower)
person_confidence: 0.5  # Balanced
person_confidence: 0.7  # Detect fewer people (faster)
```

**Impact:**
- Lower = More detections = Slower
- Higher = Fewer detections = Faster

**Recommendation:** 0.5 for most cases

---

## 🚀 Advanced Optimizations

### **1. Use Lower Camera Resolution**

**In IP Webcam App (Phone):**
- Settings → Video Resolution → **640x480** or **1280x720**

**For CCTV:**
- Use camera's "SubStream" instead of "MainStream"
- Example: `/Streaming/Channels/102` (substream) instead of `/101` (main)

**Impact:** 2-3x faster processing

---

### **2. Reduce Detection Classes**

**Current:** Detects both persons (class 0) and phones (class 67)

**If phone detection not needed:**
Edit `detect.py` line ~225:
```python
# Change from:
results = model.track(frame, persist=True, classes=[0, 67], conf=0.3, ...)

# To (person only):
results = model.track(frame, persist=True, classes=[0], conf=0.3, ...)
```

**Impact:** 10-20% faster

---

### **3. Reduce Face Database Size**

**Current:** All registered faces are checked for every unknown person

**Optimization:** Limit number of registered users to 20-30

**Why:** More faces = slower matching

---

### **4. GPU Acceleration (NVIDIA Only)**

**Requirements:**
- NVIDIA GPU (GTX 1650 or better)
- CUDA Toolkit installed
- cuDNN installed

**Setup:**
1. Install CUDA: https://developer.nvidia.com/cuda-downloads
2. Install cuDNN: https://developer.nvidia.com/cudnn
3. Reinstall PyTorch with CUDA:
   ```bash
   pip uninstall torch torchvision
   pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
   ```

4. Update `detect.py` for GPU:
   ```python
   # Line ~195
   app = FaceAnalysis(name='buffalo_l', providers=['CUDAExecutionProvider', 'CPUExecutionProvider'])
   ```

**Impact:** 3-5x faster face recognition

---

## 📈 Performance Benchmarks

### **CPU-Only (Intel i5 8th Gen, 8GB RAM)**
| Configuration | FPS | Quality |
|---------------|-----|---------|
| Maximum Speed (frame_skip=3, face_check=10) | 12-15 | Good |
| Balanced (frame_skip=2, face_check=5) | 8-12 | Very Good |
| Maximum Quality (frame_skip=1, face_check=2) | 4-7 | Excellent |

### **With GPU (GTX 1650, Intel i5, 8GB RAM)**
| Configuration | FPS | Quality |
|---------------|-----|---------|
| Maximum Speed | 25-30 | Good |
| Balanced | 20-25 | Very Good |
| Maximum Quality | 15-20 | Excellent |

---

## 🐛 Troubleshooting Slow Performance

### **Problem: FPS below 5**

**Solutions:**
1. ✅ Increase `frame_skip` to 3 or 4
2. ✅ Increase `face_check_interval` to 10 or 15
3. ✅ Use lower camera resolution
4. ✅ Close other programs using CPU
5. ✅ Reduce `person_confidence` to 0.6

### **Problem: Face recognition too slow**

**Solutions:**
1. ✅ Increase `face_check_interval` to 10
2. ✅ Reduce number of registered users
3. ✅ Use GPU acceleration (if available)

### **Problem: People not detected quickly**

**Solutions:**
1. ✅ Reduce `frame_skip` to 1 or 2
2. ✅ Lower `person_confidence` to 0.4
3. ✅ Reduce `face_check_interval` to 3

---

## 💡 Recommended Deployment Settings

### **For Office (5-10 users, normal PC)**
```yaml
camera:
  frame_skip: 2

detection:
  person_confidence: 0.5
  phone_confidence: 0.3
  face_check_interval: 5
```

### **For High-Security (many users, good PC)**
```yaml
camera:
  frame_skip: 1

detection:
  person_confidence: 0.45
  phone_confidence: 0.25
  face_check_interval: 3
```

### **For Budget Setup (old PC, many users)**
```yaml
camera:
  frame_skip: 3

detection:
  person_confidence: 0.6
  phone_confidence: 0.4
  face_check_interval: 10
```

---

## 🎚️ Real-Time Performance Tuning

### **During Deployment:**

1. **Start conservative (fast settings):**
   ```yaml
   frame_skip: 3
   face_check_interval: 10
   ```

2. **Check FPS on video window** (top-left corner)

3. **If FPS > 20:** Can improve quality
   ```yaml
   frame_skip: 2  # More frames
   face_check_interval: 5  # Check faces more often
   ```

4. **If FPS < 8:** Need more speed
   ```yaml
   frame_skip: 4  # Skip more frames
   face_check_interval: 15  # Check faces less often
   ```

5. **Restart detection script** after config changes:
   ```bash
   # Stop: Ctrl+C
   # Start: python detect.py
   ```

---

## 📊 Monitoring Performance

### **Watch FPS Counter**
- **Green FPS number** shown on video window
- Updates every second
- Target: 10-20 FPS for good performance

### **Watch CPU Usage**
- Open Task Manager (Ctrl+Shift+Esc)
- Watch "python.exe" CPU usage
- Should be 50-80% on one core
- If 100% constantly = too slow

---

## 🏆 Best Practices

### **✅ DO:**
- Start with balanced settings (frame_skip=2, face_check=5)
- Monitor FPS counter during deployment
- Adjust settings based on actual performance
- Use lower camera resolution if possible
- Register only necessary users

### **❌ DON'T:**
- Set frame_skip=1 on slow CPUs (will be very slow)
- Register 100+ users (slows face matching)
- Use 4K camera streams (overkill for face recognition)
- Set face_check_interval=1 (unnecessarily slow)

---

## 🎯 Quick Reference Table

| Need | Setting | Value |
|------|---------|-------|
| **More Speed** | frame_skip | 3 or 4 |
| | face_check_interval | 10 or 15 |
| | person_confidence | 0.6 or 0.7 |
| **Better Accuracy** | frame_skip | 1 or 2 |
| | face_check_interval | 2 or 3 |
| | person_confidence | 0.4 or 0.45 |
| **Balanced** | frame_skip | 2 |
| | face_check_interval | 5 |
| | person_confidence | 0.5 |

---

**Your system is now optimized! 🚀**

Start with balanced settings and adjust based on FPS counter during deployment.
