"""
Hikvision DVR Stream Test
Connect your laptop to their LAN, run this, confirm details
"""

import cv2
from urllib.parse import quote

print("\n" + "="*60)
print("HIKVISION DVR STREAM TEST")
print("="*60)

# Pre-filled defaults from on-site DVR
DEFAULT_IP = "192.168.1.101"
DEFAULT_USER = "admin"
DEFAULT_PASS = "martial@1305"
DEFAULT_CHANNEL = "1"

# Get details (press Enter to use defaults)
print(f"\nPress Enter to use default values shown in [brackets]\n")
dvr_ip = input(f"DVR IP [{DEFAULT_IP}]: ").strip() or DEFAULT_IP
username = input(f"Username [{DEFAULT_USER}]: ").strip() or DEFAULT_USER
password = input(f"Password [{DEFAULT_PASS}]: ").strip() or DEFAULT_PASS
channel = input(f"Camera Channel [{DEFAULT_CHANNEL}]: ").strip() or DEFAULT_CHANNEL

# URL-encode the password (handles special chars like @ in 'martial@1305')
encoded_password = quote(password, safe='')

# Build RTSP URLs - Hikvision format
# Channel 1: 101 (main), 102 (sub)
# Channel 2: 201 (main), 202 (sub)
channel_num = int(channel)
main_stream_code = channel_num * 100 + 1   # 101, 201, 301...
sub_stream_code = channel_num * 100 + 2    # 102, 202, 302...

rtsp_main = f"rtsp://{username}:{encoded_password}@{dvr_ip}:554/Streaming/Channels/{main_stream_code}"
rtsp_sub = f"rtsp://{username}:{encoded_password}@{dvr_ip}:554/Streaming/Channels/{sub_stream_code}"

# Display URL (with raw password for readability)
print(f"\nDVR IP: {dvr_ip}")
print(f"Web Interface: http://{dvr_ip}:81")
print(f"Channel: {channel}")
print(f"\nMain stream: rtsp://{username}:{password}@{dvr_ip}:554/Streaming/Channels/{main_stream_code}")
print(f"Sub stream:  rtsp://{username}:{password}@{dvr_ip}:554/Streaming/Channels/{sub_stream_code}")

# Try sub-stream first (recommended for detection - less bandwidth)
print(f"\n--- Testing SUB stream (Channel {channel}) ---")
print("Connecting...")

cap = cv2.VideoCapture(rtsp_sub)

if not cap.isOpened():
    print("❌ Sub stream failed, trying MAIN stream...")
    cap = cv2.VideoCapture(rtsp_main)

if not cap.isOpened():
    print("\n❌ FAILED - Cannot connect to DVR!")
    print("\nTroubleshooting:")
    print(f"1. Ping the DVR: ping {dvr_ip}")
    print(f"2. Check web interface: http://{dvr_ip}:81")
    print("3. Verify username/password on DVR local display")
    print("4. Check if RTSP is enabled in DVR network settings")
    print("5. RTSP port might not be 554 - check DVR network config")
    print(f"6. Make sure Channel {channel} has a camera connected")
    print("7. Try a different channel number")
else:
    ret, frame = cap.read()
    if ret:
        h, w = frame.shape[:2]
        print(f"✅ Connected! Resolution: {w}x{h}")
    print(f"\n✅ DVR Channel {channel} is working!")
    print("Showing live video... Press 'q' to quit\n")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Lost connection")
            break

        cv2.putText(frame, f"DVR Ch{channel} - Press Q to quit",
                   (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        cv2.imshow("DVR Test", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    print("\n✅ Test completed!")
    print(f"\nYour working RTSP URL for config.yaml:")
    print(f"  {rtsp_sub}")
    print(f"\nCopy this to config.yaml as camera_source")
