"""
Camera Connection Test Script
Tests RTSP/Webcam connection before running full system
"""

import cv2
import sys
from config_loader import get_config

def test_camera_connection():
    """Test camera connection and display basic info"""

    print("=" * 60)
    print("VIDEO ANALYTICS - CAMERA CONNECTION TEST")
    print("=" * 60)

    # Load configuration
    try:
        config = get_config()
        camera_source = config.camera_source
    except Exception as e:
        print(f"❌ Error loading config.yaml: {e}")
        return False

    print(f"\n📹 Camera Source: {camera_source}")

    # Determine camera type
    is_rtsp = isinstance(camera_source, str) and camera_source.lower().startswith('rtsp')
    is_http = isinstance(camera_source, str) and (camera_source.lower().startswith('http://') or camera_source.lower().startswith('https://'))

    if is_rtsp:
        print("📡 Type: RTSP IP Camera")
    elif is_http:
        print("🌐 Type: HTTP Stream (IP Webcam/MJPEG)")
    else:
        print("🎥 Type: Local Webcam")

    print("\n⏳ Attempting to connect...")

    # Try to connect
    try:
        if is_rtsp or is_http:
            # Network stream - don't use CAP_DSHOW
            cap = cv2.VideoCapture(camera_source)
        else:
            # Local webcam
            cap = cv2.VideoCapture(camera_source, cv2.CAP_DSHOW if sys.platform == 'win32' else None)

        if not cap.isOpened():
            print("❌ FAILED: Cannot open camera")
            print("\n💡 Troubleshooting Tips:")
            print("   1. Verify RTSP URL is correct")
            print("   2. Check camera credentials (username/password)")
            print("   3. Test URL in VLC Media Player first")
            print("   4. Verify camera is on same network")
            print("   5. Check firewall settings")
            return False

        print("✅ Camera opened successfully!")

        # Try to read a frame
        print("⏳ Reading test frame...")
        ret, frame = cap.read()

        if not ret or frame is None:
            print("❌ FAILED: Cannot read frames from camera")
            print("\n💡 Troubleshooting Tips:")
            print("   1. Camera may not be streaming")
            print("   2. Try different stream path (/stream1, /stream2, etc.)")
            print("   3. Check camera encoding settings (H.264 recommended)")
            print("   4. Verify network bandwidth is sufficient")
            cap.release()
            return False

        print("✅ Frame read successfully!")

        # Get camera properties
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))

        print("\n" + "=" * 60)
        print("📊 CAMERA INFORMATION")
        print("=" * 60)
        print(f"Resolution: {width} x {height}")
        print(f"FPS: {fps if fps > 0 else 'Unknown'}")
        print(f"Frame Shape: {frame.shape}")
        print(f"Color Mode: {'Color (BGR)' if len(frame.shape) == 3 else 'Grayscale'}")

        # Calculate approximate bitrate
        if fps > 0:
            frame_size = frame.size * frame.itemsize  # bytes
            bitrate_mbps = (frame_size * fps * 8) / (1024 * 1024)
            print(f"Est. Bandwidth: {bitrate_mbps:.2f} Mbps")

        print("\n" + "=" * 60)
        print("✅ CONNECTION TEST PASSED!")
        print("=" * 60)
        print("\n💡 Next Steps:")
        print("   1. The system is ready to use")
        print("   2. Start the web dashboard: python main.py")
        print("   3. Start the detection engine: python detect.py")
        print("   4. Access dashboard at: http://localhost:5000")

        # Show live preview
        print("\n📺 Displaying live preview (Press 'q' to quit)...")

        while True:
            ret, frame = cap.read()
            if not ret:
                print("⚠️  Lost connection to camera")
                break

            # Add info overlay
            cv2.putText(frame, f"Resolution: {width}x{height}", (10, 30),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, "Press 'q' to quit", (10, 70),
                       cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            cv2.imshow("Camera Test - Live Preview", frame)

            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        return True

    except Exception as e:
        print(f"❌ ERROR: {e}")
        print("\n💡 Troubleshooting Tips:")
        print("   1. Check if OpenCV is installed correctly")
        print("   2. Verify camera source in config.yaml")
        print("   3. Test RTSP URL in VLC Media Player")
        return False

if __name__ == "__main__":
    print("\n")
    success = test_camera_connection()
    print("\n")

    if not success:
        sys.exit(1)
    else:
        sys.exit(0)
