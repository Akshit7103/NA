"""
Super quick NVR connection test
Only needs opencv-python installed
"""
import cv2

# Enter your details here
nvr_ip = "192.168.1.26"
username = "admin"
password = "admin"  # Change this
channel = "1"

# Build URL
channel_code = str(int(channel) * 100 + 2)
url = f"rtsp://{username}:{password}@{nvr_ip}:554/Streaming/Channels/{channel_code}"

print(f"\nTesting: {url}")
print("Connecting...\n")

cap = cv2.VideoCapture(url)

if cap.isOpened():
    print("✅ SUCCESS! Connected to NVR!")
    print("✅ Stream is working!")
    ret, frame = cap.read()
    if ret:
        h, w = frame.shape[:2]
        print(f"✅ Video resolution: {w}x{h}")
        print("\nShowing video... Press 'q' to quit")

        while True:
            ret, frame = cap.read()
            if not ret:
                break
            cv2.imshow("NVR Test", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        print("\n✅ NVR connection VERIFIED!")
        print(f"\nUse this in config.yaml:\nsource: \"{url}\"")
else:
    print("❌ FAILED - Cannot connect")
    print("\nCheck:")
    print("1. Are you on same LAN network?")
    print("2. Can you ping", nvr_ip, "?")
    print("3. Is username/password correct?")
    print("4. Try accessing in browser: http://" + nvr_ip)
