"""
Configuration Loader for Video Analytics System
Loads settings from config.yaml
"""

import yaml
import os
from typing import Any, Dict

class Config:
    """Configuration manager for the application"""

    def __init__(self, config_file: str = "config.yaml"):
        self.config_file = config_file
        self._config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        if not os.path.exists(self.config_file):
            raise FileNotFoundError(f"Configuration file '{self.config_file}' not found!")

        with open(self.config_file, 'r') as f:
            config = yaml.safe_load(f)

        return config

    def get(self, key_path: str, default=None):
        """
        Get configuration value using dot notation
        Example: config.get('camera.source')
        """
        keys = key_path.split('.')
        value = self._config

        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default

        return value

    def reload(self):
        """Reload configuration from file"""
        self._config = self._load_config()

    # Convenience properties for commonly used settings
    @property
    def camera_source(self):
        return self.get('camera.source', 0)

    @property
    def is_rtsp(self) -> bool:
        """Check if camera source is RTSP stream"""
        source = self.camera_source
        return isinstance(source, str) and source.lower().startswith('rtsp')

    @property
    def reconnect_attempts(self):
        return self.get('camera.reconnect_attempts', 5)

    @property
    def reconnect_delay(self):
        return self.get('camera.reconnect_delay', 5)

    @property
    def frame_skip(self):
        return self.get('camera.frame_skip', 1)

    @property
    def faces_dir(self):
        return self.get('storage.faces_dir', 'data/faces')

    @property
    def db_path(self):
        return self.get('database.path', 'data/database.db')

    @property
    def face_similarity_threshold(self):
        return self.get('detection.face_similarity', 0.5)

    @property
    def log_cooldown(self):
        return self.get('timing.log_cooldown', 30)

    @property
    def phone_alert_cooldown(self):
        return self.get('timing.phone_alert_cooldown', 10)

    @property
    def unauthorized_face_grace(self):
        return self.get('timing.unauthorized_face_grace', 3.0)

    @property
    def unauthorized_no_face_grace(self):
        return self.get('timing.unauthorized_no_face_grace', 15.0)

    @property
    def track_timeout(self):
        return self.get('timing.track_timeout', 5.0)

# Global config instance
_config = None

def get_config(config_file: str = "config.yaml") -> Config:
    """Get or create global config instance"""
    global _config
    if _config is None:
        _config = Config(config_file)
    return _config
