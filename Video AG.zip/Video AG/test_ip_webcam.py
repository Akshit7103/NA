"""
Quick diagnostic tool for IP Webcam connectivity
Tests various connection methods
"""

import requests
import cv2
import time

# Your phone's IP from screenshot
PHONE_IP = "100.81.223.114"
PORT = "8080"

print("=" * 60)
print("IP WEBCAM DIAGNOSTIC TOOL")
print("=" * 60)

# Test 1: Basic HTTP connectivity
print("\n[Test 1] Testing basic HTTP connection...")
try:
    url = f"http://{PHONE_IP}:{PORT}"
    response = requests.get(url, timeout=5)
    if response.status_code == 200:
        print(f"✅ SUCCESS: Can reach IP Webcam at {url}")
        print(f"   Response: {response.status_code}")
    else:
        print(f"⚠️  WARNING: Got response but status code: {response.status_code}")
except requests.exceptions.Timeout:
    print(f"❌ FAILED: Connection timeout")
    print(f"   → IP Webcam app might not be running")
    print(f"   → Check if phone shows: {url}")
except requests.exceptions.ConnectionError:
    print(f"❌ FAILED: Cannot connect to {url}")
    print(f"   → Make sure IP Webcam app is running")
    print(f"   → Check if IP address is still {PHONE_IP}")
    print(f"   → Verify phone and PC are on same WiFi")
except Exception as e:
    print(f"❌ ERROR: {e}")

# Test 2: Test available stream endpoints
print("\n[Test 2] Testing stream endpoints...")
stream_urls = [
    "/video",           # H.264 video stream
    "/videofeed",       # MJPEG feed
    "/shot.jpg",        # Single snapshot
    "/photoaf.jpg",     # Auto-focus snapshot
]

working_urls = []
for endpoint in stream_urls:
    try:
        url = f"http://{PHONE_IP}:{PORT}{endpoint}"
        response = requests.get(url, timeout=3, stream=True)
        if response.status_code == 200:
            print(f"✅ {endpoint:20} - Working")
            working_urls.append(url)
        else:
            print(f"❌ {endpoint:20} - Failed ({response.status_code})")
    except:
        print(f"❌ {endpoint:20} - Connection failed")

# Test 3: Try OpenCV connection with working URLs
if working_urls:
    print(f"\n[Test 3] Testing OpenCV VideoCapture with {len(working_urls)} working URLs...")

    for url in working_urls:
        print(f"\n   Trying: {url}")
        try:
            cap = cv2.VideoCapture(url)

            if not cap.isOpened():
                print(f"   ❌ VideoCapture failed to open")
                continue

            print(f"   ✅ VideoCapture opened!")

            # Try reading a frame
            ret, frame = cap.read()
            if ret and frame is not None:
                h, w = frame.shape[:2]
                print(f"   ✅ Frame read successful! Resolution: {w}x{h}")
                print(f"\n   🎉 THIS URL WORKS WITH OPENCV!")
                print(f"   → Use this in config.yaml: source: \"{url}\"")

                # Show preview
                print(f"\n   📺 Showing 5-second preview...")
                start = time.time()
                while time.time() - start < 5:
                    ret, frame = cap.read()
                    if ret:
                        cv2.imshow("Preview", frame)
                        if cv2.waitKey(1) & 0xFF == ord('q'):
                            break
                cv2.destroyAllWindows()
                cap.release()
                break
            else:
                print(f"   ❌ Could not read frame")

            cap.release()
        except Exception as e:
            print(f"   ❌ Error: {e}")
else:
    print("\n[Test 3] ⚠️ Skipped - No working URLs found")

# Summary
print("\n" + "=" * 60)
print("DIAGNOSTIC SUMMARY")
print("=" * 60)

if working_urls:
    print(f"✅ Found {len(working_urls)} working stream(s)")
    print("\nWorking URLs:")
    for url in working_urls:
        print(f"   • {url}")
    print("\n💡 Update config.yaml with one of the working URLs above")
else:
    print("❌ No working streams found")
    print("\n💡 Troubleshooting Steps:")
    print("   1. Make sure IP Webcam app is running on your phone")
    print("   2. Check the IP address displayed in the app")
    print("   3. Verify phone and PC are on the same WiFi network")
    print("   4. Try accessing http://{}:{} in your browser".format(PHONE_IP, PORT))
    print("   5. Temporarily disable Windows Firewall to test")

print("=" * 60)
