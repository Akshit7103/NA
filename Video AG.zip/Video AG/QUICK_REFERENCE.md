# 🚀 Quick Reference - CCTV Deployment

## ⚡ 30-Second Setup

### 1. Get RTSP URL from camera
```
rtsp://admin:password@192.168.1.64:554/stream1
```

### 2. Edit `config.yaml`
```yaml
camera:
  source: "rtsp://admin:password@192.168.1.64:554/stream1"  # YOUR URL HERE
```

### 3. Test Connection
```bash
python test_camera.py
```

### 4. Start System
```bash
# Terminal 1
python main.py

# Terminal 2
python detect.py
```

### 5. Access Dashboard
```
http://localhost:5000
Login: admin / admin123
```

---

## 📝 Common RTSP URL Formats

| Brand | Format |
|-------|--------|
| **Hikvision** | `rtsp://admin:pass@IP:554/Streaming/Channels/101` |
| **Dahua** | `rtsp://admin:pass@IP:554/cam/realmonitor?channel=1&subtype=0` |
| **Uniview** | `rtsp://admin:pass@IP:554/unicast/c1/s0/live` |
| **Generic** | `rtsp://admin:pass@IP:554/stream1` |

---

## 🎛️ Key Configuration Settings

### Performance Tuning
```yaml
camera:
  frame_skip: 1  # 1=all frames, 2=half speed, 3=third speed
```

### Detection Sensitivity
```yaml
detection:
  face_similarity: 0.5  # Higher=stricter (0.4-0.6)
  person_confidence: 0.5  # Lower=more detections (0.3-0.7)
  phone_confidence: 0.3  # Lower=more phones (0.2-0.5)
```

### Timing
```yaml
timing:
  unauthorized_face_grace: 3.0   # Seconds before alert
  unauthorized_no_face_grace: 15.0
  log_cooldown: 30  # Cooldown between same person logs
```

---

## 🐛 Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| **Can't connect** | Test in VLC first, verify credentials |
| **Too slow** | Increase `frame_skip` to 2 or 3 |
| **False alarms** | Increase `face_similarity` to 0.55 |
| **Missing people** | Lower `person_confidence` to 0.4 |
| **Missing phones** | Lower `phone_confidence` to 0.25 |
| **Connection drops** | System auto-reconnects (check network) |

---

## 📂 Important Files

```
config.yaml          ← Main configuration (EDIT THIS)
test_camera.py       ← Test RTSP connection
main.py              ← Web dashboard server
detect.py            ← Detection engine
database.py          ← Database operations
DEPLOYMENT_GUIDE.md  ← Full documentation
```

---

## 🔒 Security Checklist

- [ ] Change admin password (default: admin123)
- [ ] Change `server.secret_key` in config.yaml
- [ ] Use strong camera passwords
- [ ] Restrict network access

---

## 📊 System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| **CPU** | Intel i5 8th gen | Intel i7/i9 |
| **RAM** | 8GB | 16GB |
| **GPU** | None (CPU) | NVIDIA GTX 1650+ |
| **Camera** | 1080p IP Cam | 2K/4K IP Cam |

---

## 🔄 Auto-Start on Boot

### Windows
Use Task Scheduler to run `main.py` and `detect.py` at startup

### Linux
```bash
sudo systemctl enable video-analytics-web
sudo systemctl enable video-analytics-detect
```

---

## 📞 Quick Support

1. ✅ Test RTSP in VLC first
2. ✅ Run `python test_camera.py`
3. ✅ Check config.yaml syntax
4. ✅ Verify network connectivity
5. ✅ Read DEPLOYMENT_GUIDE.md

---

## 🎯 What Changed from Webcam to CCTV?

✅ **Automatic RTSP detection** - System detects RTSP URLs
✅ **Auto-reconnection** - Reconnects if camera drops
✅ **Config-based setup** - No code changes needed
✅ **Frame skipping** - Better performance control
✅ **Connection testing** - test_camera.py script
✅ **Better error handling** - Clear error messages

---

## 💡 Pro Tips

- **Test in VLC first** - Saves debugging time
- **Use SubStream** - Main stream may be too high quality
- **Static IP for camera** - Prevents URL changes
- **Good lighting** - Critical for face recognition
- **Camera angle 15-30°** - Optimal for face capture
- **Register 10+ photos** - Better recognition accuracy

---

**Ready to deploy? Run `python test_camera.py` first!** 🚀
