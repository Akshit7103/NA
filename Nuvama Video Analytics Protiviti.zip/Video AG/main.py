import cv2
import numpy as np
import base64
import time
import os
import sys
import re
import shutil
import io
import csv
import math
import subprocess
from typing import List, Optional

import yaml
from fastapi import FastAPI, Request, Form, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware

import socketio
import uvicorn
from werkzeug.security import check_password_hash

import database
from config_loader import get_config, setup_logging

# --- Load Configuration ---
config = get_config()

# --- Logging ---
logger = setup_logging(config, 'video_analytics.server')

# --- Server Start Time (for uptime tracking) ---
_server_start_time = time.time()

# --- Configuration ---
FACES_DIR = config.faces_dir
SNAPSHOTS_DIR = config.get('storage.snapshots_dir', 'static/snapshots')
SECRET_KEY = config.get('server.secret_key', 'super_secret_key_change_this_later')

os.makedirs(FACES_DIR, exist_ok=True)
os.makedirs(SNAPSHOTS_DIR, exist_ok=True)

# --- Database Init ---
database.init_db()
database.purge_old_logs(days=7)

# --- FastAPI App ---
app = FastAPI(title="Video Analytics Dashboard")

# Session Middleware (for Auth)
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static & Templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# --- SocketIO Setup (ASGI) ---
sio = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins='*')
socket_app = socketio.ASGIApp(sio, app)

# --- Auth Dependencies ---
def login_required(request: Request):
    """For page routes: redirects to /login if not authenticated"""
    user = request.session.get("user")
    if not user:
        raise HTTPException(
            status_code=status.HTTP_307_TEMPORARY_REDIRECT,
            headers={"Location": "/login"}
        )
    return user

def api_login_required(request: Request):
    """For API routes: returns 401 if not authenticated"""
    user = request.session.get("user")
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user

# --- Routes ---

@app.get("/", response_class=HTMLResponse)
async def index(request: Request, user: dict = Depends(login_required)):
    return templates.TemplateResponse("index.html", {"request": request, "user": user})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(request: Request, username: str = Form(...), password: str = Form(...)):
    admin = database.get_admin(username)
    if admin and check_password_hash(admin['password_hash'], password):
        request.session["user"] = {"id": admin['id'], "username": admin['username']}
        return RedirectResponse(url="/", status_code=status.HTTP_303_SEE_OTHER)
    else:
        return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid credentials"})

@app.get("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/login")

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request, user: dict = Depends(login_required)):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/users", response_class=HTMLResponse)
async def users_page(request: Request, user: dict = Depends(login_required)):
    return templates.TemplateResponse("users.html", {"request": request})

# --- API Routes ---

@app.post("/api/register")
async def api_register(request: Request, data: dict, user: dict = Depends(api_login_required)):

    name = data.get('name')
    images = data.get('images')

    if not name or not images:
        return JSONResponse({"error": "Missing data"}, status_code=400)

    user_id = database.add_user(name)
    user_dir = os.path.join(FACES_DIR, str(user_id))
    os.makedirs(user_dir, exist_ok=True)

    for i, img_data in enumerate(images):
        if img_data.startswith('data:image'):
            header, encoded = img_data.split(",", 1)
            file_data = base64.b64decode(encoded)
            with open(os.path.join(user_dir, f"{i}.jpg"), "wb") as f:
                f.write(file_data)

    return {"success": True, "user_id": user_id}

@app.post("/api/register/upload")
async def api_register_upload(request: Request, name: str = Form(...), files: List[UploadFile] = File(...), user: dict = Depends(api_login_required)):

    if not name.strip():
        return JSONResponse({"error": "Name is required"}, status_code=400)

    if not files:
        return JSONResponse({"error": "At least one image is required"}, status_code=400)

    # Validate file types
    allowed_types = {'image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'image/bmp'}
    for f in files:
        if f.content_type not in allowed_types:
            return JSONResponse({"error": f"Invalid file type: {f.filename}. Only images allowed."}, status_code=400)

    user_id = database.add_user(name.strip())
    user_dir = os.path.join(FACES_DIR, str(user_id))
    os.makedirs(user_dir, exist_ok=True)

    for i, file in enumerate(files):
        file_data = await file.read()
        # Convert all images to jpg for consistency
        img_array = np.frombuffer(file_data, np.uint8)
        img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
        if img is not None:
            cv2.imwrite(os.path.join(user_dir, f"{i}.jpg"), img)

    return {"success": True, "user_id": user_id}

@app.get("/api/users")
async def api_get_users(request: Request, user: dict = Depends(api_login_required)):
    users = database.get_users()
    return users

@app.delete("/api/users/{user_id}")
async def api_delete_user(request: Request, user_id: int, user: dict = Depends(api_login_required)):
    
    user_dir = os.path.join(FACES_DIR, str(user_id))
    if os.path.exists(user_dir):
        shutil.rmtree(user_dir)
        
    database.delete_user(user_id)
    return {"success": True}

@app.put("/api/users/{user_id}")
async def api_update_user(request: Request, user_id: int, data: dict, user: dict = Depends(api_login_required)):
    
    new_name = data.get('name')
    if new_name:
        database.update_user(user_id, new_name)
        return {"success": True}
    return JSONResponse({"error": "No name provided"}, status_code=400)

@app.get("/api/logs")
async def api_logs(
    request: Request,
    search: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    event_type: Optional[str] = None,
    page: int = 1,
    per_page: int = 25,
    user: dict = Depends(api_login_required)
):
    # Clamp per_page to reasonable bounds
    per_page = max(10, min(per_page, 100))
    page = max(1, page)

    if search or start_date or end_date or (event_type and event_type != 'all'):
        logs, total = database.search_logs(search, start_date, end_date, event_type, page=page, per_page=per_page)
    else:
        logs, total = database.get_logs(page=page, per_page=per_page)

    total_pages = max(1, math.ceil(total / per_page))

    return {
        "logs": logs,
        "total": total,
        "page": page,
        "per_page": per_page,
        "total_pages": total_pages,
    }

@app.get("/api/export_logs")
async def export_logs(
    request: Request,
    search: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    event_type: Optional[str] = None,
    user: dict = Depends(api_login_required)
):
    logs = database.search_logs_all(search, start_date, end_date, event_type)

    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['ID', 'Timestamp', 'Source', 'Event Type', 'User', 'Snapshot'])
    for log in logs:
        cw.writerow([log['id'], log['timestamp'], log.get('source', ''), log['event_type'], log['user_name'], log.get('snapshot_path', '')])
    
    return StreamingResponse(
        iter([si.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=security_logs.csv"}
    )

@app.post("/api/logs/clear")
async def api_clear_logs(request: Request, user: dict = Depends(api_login_required)):
    """Delete all logs and associated snapshots"""
    deleted = database.clear_all_logs()
    return {"success": True, "deleted": deleted}

@app.get("/api/health")
async def api_health():
    """Health check endpoint - no auth required"""
    import sqlite3 as _sqlite3

    # DB check
    db_ok = False
    try:
        conn = _sqlite3.connect(database.DB_NAME)
        conn.execute("SELECT 1")
        conn.close()
        db_ok = True
    except Exception:
        pass

    # Uptime
    uptime_seconds = int(time.time() - _server_start_time)
    hours, remainder = divmod(uptime_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    # Camera processes
    active_cameras = sum(
        1 for p in camera_processes.values()
        if p is not None and p.poll() is None
    )

    return {
        "status": "healthy" if db_ok else "degraded",
        "database": "ok" if db_ok else "error",
        "uptime": f"{hours}h {minutes}m {seconds}s",
        "uptime_seconds": uptime_seconds,
        "active_cameras": active_cameras,
    }


# --- Snapshot Gallery ---

@app.get("/snapshots", response_class=HTMLResponse)
async def snapshots_page(request: Request, user: dict = Depends(login_required)):
    return templates.TemplateResponse("snapshots.html", {"request": request})

@app.get("/api/snapshots")
async def api_get_snapshots(request: Request, user: dict = Depends(api_login_required)):
    """List all snapshot files with metadata"""
    snapshots = []
    if os.path.exists(SNAPSHOTS_DIR):
        for fname in sorted(os.listdir(SNAPSHOTS_DIR), reverse=True):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                fpath = os.path.join(SNAPSHOTS_DIR, fname)
                stat = os.stat(fpath)
                snapshots.append({
                    'filename': fname,
                    'path': f"/static/snapshots/{fname}",
                    'size': stat.st_size,
                    'modified': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_mtime)),
                })
    return snapshots

@app.delete("/api/snapshots/{filename}")
async def api_delete_snapshot(request: Request, filename: str, user: dict = Depends(api_login_required)):
    """Delete a single snapshot"""
    # Security: only allow image filenames, no path traversal
    if '/' in filename or '\\' in filename or '..' in filename:
        raise HTTPException(400, "Invalid filename")
    fpath = os.path.join(SNAPSHOTS_DIR, filename)
    if not os.path.exists(fpath):
        raise HTTPException(404, "Snapshot not found")
    os.remove(fpath)
    return {"success": True}

@app.post("/api/snapshots/delete-all")
async def api_delete_all_snapshots(request: Request, user: dict = Depends(api_login_required)):
    """Delete all snapshots"""
    deleted = 0
    if os.path.exists(SNAPSHOTS_DIR):
        for fname in os.listdir(SNAPSHOTS_DIR):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                os.remove(os.path.join(SNAPSHOTS_DIR, fname))
                deleted += 1
    return {"success": True, "deleted": deleted}


# --- User Photo Management ---

@app.get("/api/users/{user_id}/photo")
async def api_get_user_photo(request: Request, user_id: int, user: dict = Depends(api_login_required)):
    """Check if user has a face photo"""
    user_dir = os.path.join(FACES_DIR, str(user_id))
    if os.path.exists(user_dir):
        for fname in sorted(os.listdir(user_dir)):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                return {"has_photo": True}
    return {"has_photo": False}

@app.get("/api/users/{user_id}/photo/image")
async def api_serve_user_photo(request: Request, user_id: int, user: dict = Depends(api_login_required)):
    """Serve the user's face photo directly"""
    user_dir = os.path.join(FACES_DIR, str(user_id))
    if os.path.exists(user_dir):
        for fname in sorted(os.listdir(user_dir)):
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                img_path = os.path.join(user_dir, fname)
                with open(img_path, 'rb') as f:
                    img_data = f.read()
                return StreamingResponse(
                    iter([img_data]),
                    media_type="image/jpeg"
                )
    raise HTTPException(404, "No photo found")

@app.put("/api/users/{user_id}/photo")
async def api_replace_user_photo(request: Request, user_id: int, file: UploadFile = File(...), user: dict = Depends(api_login_required)):
    """Replace user's face photo with a new one (single photo per person)"""
    user_dir = os.path.join(FACES_DIR, str(user_id))
    if not os.path.exists(user_dir):
        os.makedirs(user_dir, exist_ok=True)

    # Validate file type
    allowed_types = {'image/jpeg', 'image/png', 'image/jpg', 'image/webp', 'image/bmp'}
    if file.content_type not in allowed_types:
        return JSONResponse({"error": "Invalid file type. Only images allowed."}, status_code=400)

    # Remove all existing photos
    for old_file in os.listdir(user_dir):
        os.remove(os.path.join(user_dir, old_file))

    # Save new photo as 0.jpg
    file_data = await file.read()
    img_array = np.frombuffer(file_data, np.uint8)
    img = cv2.imdecode(img_array, cv2.IMREAD_COLOR)
    if img is None:
        return JSONResponse({"error": "Could not decode image"}, status_code=400)

    cv2.imwrite(os.path.join(user_dir, "0.jpg"), img)
    return {"success": True}


# --- Camera Process Management ---
# Tracks running detection subprocesses: config_filename -> Popen object
camera_processes = {}
# Tracks which cameras have confirmed live feed: config_filename -> True
camera_live_status = {}

def _discover_cameras() -> list:
    """Scan for all config*.yaml files and extract camera info"""
    import glob as glob_mod
    cameras = []
    project_dir = os.path.dirname(os.path.abspath(__file__))
    config_files = sorted(glob_mod.glob(os.path.join(project_dir, "config*.yaml")))

    for filepath in config_files:
        filename = os.path.basename(filepath)
        try:
            with open(filepath, 'r') as f:
                cfg = yaml.safe_load(f)
            if not cfg:
                continue

            # Handle both config formats:
            # Structured: camera.source / camera.name
            # Flat: source / camera_name
            if isinstance(cfg.get('camera'), dict):
                source = cfg['camera'].get('source', 'N/A')
                name = cfg['camera'].get('name', None)
            else:
                source = cfg.get('source', 'N/A')
                name = cfg.get('camera_name', None)

            # Fallback name: derive from filename
            if not name:
                name = filename.replace('config_', '').replace('config', 'Default').replace('.yaml', '').replace('_', ' ').title()

            # Three-state status: stopped -> running -> live
            proc = camera_processes.get(filename)
            is_process_alive = proc is not None and proc.poll() is None
            is_live = camera_live_status.get(filename, False) and is_process_alive

            if not is_process_alive:
                cam_status = 'stopped'
                # Clean up stale live status
                camera_live_status.pop(filename, None)
            elif is_live:
                cam_status = 'live'
            else:
                cam_status = 'running'

            cameras.append({
                'config': filename,
                'name': name,
                'source': str(source),
                'status': cam_status,
            })
        except Exception as e:
            logger.error(f"Error reading {filename}: {e}")
            cameras.append({
                'config': filename,
                'name': filename,
                'source': 'Error reading config',
                'status': 'error',
            })
    return cameras

@app.get("/cameras", response_class=HTMLResponse)
async def cameras_page(request: Request, user: dict = Depends(login_required)):
    return templates.TemplateResponse("cameras.html", {"request": request})

@app.get("/api/cameras")
async def api_get_cameras(request: Request, user: dict = Depends(api_login_required)):
    return _discover_cameras()

@app.post("/api/cameras/start")
async def api_start_camera(request: Request, data: dict, user: dict = Depends(api_login_required)):

    config_file = data.get('config')
    if not config_file:
        return JSONResponse({"error": "Missing config filename"}, status_code=400)

    # Security: only allow filenames that match config*.yaml pattern
    if not re.match(r'^config[\w]*\.yaml$', config_file):
        return JSONResponse({"error": "Invalid config filename"}, status_code=400)

    project_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(project_dir, config_file)
    if not os.path.exists(config_path):
        return JSONResponse({"error": f"Config file '{config_file}' not found"}, status_code=404)

    # Check if already running
    proc = camera_processes.get(config_file)
    if proc is not None and proc.poll() is None:
        return JSONResponse({"error": "Camera is already running"}, status_code=409)

    # Spawn detect.py as a subprocess
    detect_script = os.path.join(project_dir, "detect.py")
    proc = subprocess.Popen(
        [sys.executable, detect_script, "--config", config_file],
        cwd=project_dir,
    )
    camera_processes[config_file] = proc
    camera_live_status.pop(config_file, None)  # Reset live status
    return {"success": True, "pid": proc.pid, "config": config_file}

@app.post("/api/cameras/stop")
async def api_stop_camera(request: Request, data: dict, user: dict = Depends(api_login_required)):

    config_file = data.get('config')
    if not config_file:
        return JSONResponse({"error": "Missing config filename"}, status_code=400)

    proc = camera_processes.get(config_file)
    if proc is None or proc.poll() is not None:
        # Clean up stale entry
        camera_processes.pop(config_file, None)
        camera_live_status.pop(config_file, None)
        return JSONResponse({"error": "Camera is not running"}, status_code=409)

    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
    camera_processes.pop(config_file, None)
    camera_live_status.pop(config_file, None)
    return {"success": True, "config": config_file}

@app.post("/api/cameras/start-all")
async def api_start_all_cameras(request: Request, user: dict = Depends(api_login_required)):

    cameras = _discover_cameras()
    started = []
    project_dir = os.path.dirname(os.path.abspath(__file__))
    detect_script = os.path.join(project_dir, "detect.py")

    for cam in cameras:
        config_file = cam['config']
        # Skip already running
        proc = camera_processes.get(config_file)
        if proc is not None and proc.poll() is None:
            continue
        config_path = os.path.join(project_dir, config_file)
        if os.path.exists(config_path):
            proc = subprocess.Popen(
                [sys.executable, detect_script, "--config", config_file],
                cwd=project_dir,
            )
            camera_processes[config_file] = proc
            camera_live_status.pop(config_file, None)
            started.append(config_file)

    return {"success": True, "started": started}

@app.post("/api/cameras/stop-all")
async def api_stop_all_cameras(request: Request, user: dict = Depends(api_login_required)):

    stopped = []
    for config_file, proc in list(camera_processes.items()):
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            stopped.append(config_file)
        camera_processes.pop(config_file, None)
        camera_live_status.pop(config_file, None)

    return {"success": True, "stopped": stopped}

def _validate_config_file(config_file: str):
    """Validate config filename and return full path, or None"""
    if not config_file or not re.match(r'^config[\w]*\.yaml$', config_file):
        return None
    project_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(project_dir, config_file)

def _is_camera_running(config_file: str) -> bool:
    proc = camera_processes.get(config_file)
    return proc is not None and proc.poll() is None

@app.post("/api/cameras/update-source")
async def api_update_camera_source(request: Request, data: dict, user: dict = Depends(api_login_required)):

    config_file = data.get('config')
    new_source = data.get('source')
    if not config_file or new_source is None:
        return JSONResponse({"error": "Missing config or source"}, status_code=400)

    config_path = _validate_config_file(config_file)
    if not config_path or not os.path.exists(config_path):
        return JSONResponse({"error": "Invalid or missing config file"}, status_code=400)

    if _is_camera_running(config_file):
        return JSONResponse({"error": "Stop the camera before changing source"}, status_code=409)

    try:
        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)

        # Try to parse as int (webcam index) if it looks like one
        try:
            new_source = int(new_source)
        except (ValueError, TypeError):
            pass

        if isinstance(cfg.get('camera'), dict):
            cfg['camera']['source'] = new_source
        else:
            cfg['source'] = new_source

        with open(config_path, 'w') as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        return {"success": True}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/cameras/rename")
async def api_rename_camera(request: Request, data: dict, user: dict = Depends(api_login_required)):

    config_file = data.get('config')
    new_name = data.get('name', '').strip()
    if not config_file or not new_name:
        return JSONResponse({"error": "Missing config or name"}, status_code=400)

    config_path = _validate_config_file(config_file)
    if not config_path or not os.path.exists(config_path):
        return JSONResponse({"error": "Invalid or missing config file"}, status_code=400)

    try:
        with open(config_path, 'r') as f:
            cfg = yaml.safe_load(f)

        if isinstance(cfg.get('camera'), dict):
            cfg['camera']['name'] = new_name
        else:
            cfg['camera_name'] = new_name

        with open(config_path, 'w') as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)

        return {"success": True}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.post("/api/cameras/add")
async def api_add_camera(request: Request, data: dict, user: dict = Depends(api_login_required)):

    name = data.get('name', '').strip()
    source = data.get('source', '').strip()
    if not name or not source:
        return JSONResponse({"error": "Name and source are required"}, status_code=400)

    # Generate a safe filename from the name
    safe_name = re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')
    config_file = f"config_{safe_name}.yaml"

    project_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(project_dir, config_file)

    if os.path.exists(config_path):
        return JSONResponse({"error": f"A config for '{name}' already exists"}, status_code=409)

    # Try to parse source as int (webcam index)
    try:
        source = int(source)
    except (ValueError, TypeError):
        pass

    cfg = {
        'camera': {
            'name': name,
            'source': source,
            'reconnect_attempts': 5,
            'reconnect_delay': 5,
            'frame_skip': 1,
        },
        'detection': {
            'person_confidence': 0.5,
            'phone_confidence': 0.3,
            'face_similarity': 0.5,
            'face_check_interval': 5,
        },
        'timing': {
            'log_cooldown': 30,
            'phone_alert_cooldown': 10,
            'unauthorized_face_grace': 3.0,
            'unauthorized_no_face_grace': 15.0,
            'track_timeout': 5.0,
        },
        'database': {'path': 'data/database.db'},
        'storage': {'faces_dir': 'data/faces', 'snapshots_dir': 'static/snapshots'},
    }

    try:
        with open(config_path, 'w') as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)
        return {"success": True, "config": config_file}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

@app.delete("/api/cameras/{config_file}")
async def api_delete_camera(request: Request, config_file: str, user: dict = Depends(api_login_required)):

    config_path = _validate_config_file(config_file)
    if not config_path or not os.path.exists(config_path):
        return JSONResponse({"error": "Invalid or missing config file"}, status_code=400)

    if _is_camera_running(config_file):
        return JSONResponse({"error": "Stop the camera before removing it"}, status_code=409)

    try:
        os.remove(config_path)
        return {"success": True}
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)

# --- WebSockets ---

@sio.event
async def connect(sid, environ):
    logger.info("Client Connected: %s", sid)

@sio.event
async def disconnect(sid):
    logger.info("Client Disconnected: %s", sid)

@sio.event
async def log_event(sid, data):
    # Broadcast to all
    await sio.emit('new_log', data)

@sio.event
async def camera_status(sid, data):
    """Receives live status updates from detect.py subprocesses"""
    config_file = data.get('config')
    status = data.get('status')
    if config_file and status == 'live':
        camera_live_status[config_file] = True
        logger.info("Camera LIVE: %s", config_file)

# Run instructions:
# Option 1: uvicorn main:socket_app --host 0.0.0.0 --port 5000 --reload
# Option 2: python main.py

if __name__ == "__main__":
    import atexit

    # Write PID file so stop.bat can find us
    _pid_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.server.pid')
    with open(_pid_file, 'w') as f:
        f.write(str(os.getpid()))

    def _cleanup_pid():
        try:
            os.remove(_pid_file)
        except OSError:
            pass
    atexit.register(_cleanup_pid)

    host = config.get('server.host', '0.0.0.0')
    port = config.get('server.port', 5000)
    uvicorn.run("main:socket_app", host=host, port=port, reload=True)
