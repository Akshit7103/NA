import sqlite3
import datetime
import os
import logging

logger = logging.getLogger('video_analytics.database')

DB_NAME = "data/database.db"

def init_db():
    os.makedirs("data", exist_ok=True)
    conn = sqlite3.connect(DB_NAME)
    # Enable Write-Ahead Logging (WAL) for concurrency
    conn.execute("PRAGMA journal_mode=WAL;")
    c = conn.cursor()
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Logs table
    # type: 'entry', 'exit', 'phone_detected', 'unauthorized'
    c.execute('''CREATE TABLE IF NOT EXISTS logs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  user_name TEXT,
                  event_type TEXT NOT NULL,
                  source TEXT DEFAULT '',
                  snapshot_path TEXT DEFAULT '',
                  timestamp TEXT,
                  FOREIGN KEY(user_id) REFERENCES users(id))''')

    # Migration: add columns if missing (existing databases)
    c.execute("PRAGMA table_info(logs)")
    columns = [col[1] for col in c.fetchall()]
    if 'source' not in columns:
        c.execute("ALTER TABLE logs ADD COLUMN source TEXT DEFAULT ''")
    if 'snapshot_path' not in columns:
        c.execute("ALTER TABLE logs ADD COLUMN snapshot_path TEXT DEFAULT ''")

    # Indexes for query performance
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON logs(timestamp DESC)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_event_type ON logs(event_type)")
    c.execute("CREATE INDEX IF NOT EXISTS idx_logs_user_name ON logs(user_name)")

    # Admins table
    c.execute('''CREATE TABLE IF NOT EXISTS admins
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT NOT NULL UNIQUE,
                  password_hash TEXT NOT NULL)''')
                  
    conn.commit()
    conn.close()

    # Create default admin if none exists
    create_default_admin()

def create_default_admin():
    from werkzeug.security import generate_password_hash
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT count(*) FROM admins")
    if c.fetchone()[0] == 0:
        # Default: admin / admin123
        hashed = generate_password_hash("admin123")
        c.execute("INSERT INTO admins (username, password_hash) VALUES (?, ?)", ("admin", hashed))
        logger.info("Default admin created: admin / admin123")
        conn.commit()
    conn.close()

def get_admin(username):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM admins WHERE username = ?", (username,))
    row = c.fetchone()
    conn.close()
    return dict(row) if row else None

def add_user(name):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO users (name) VALUES (?)", (name,))
    user_id = c.lastrowid
    conn.commit()
    conn.close()
    return user_id

def get_users():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM users")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def delete_user(user_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id = ?", (user_id,))
    c.execute("DELETE FROM logs WHERE user_id = ?", (user_id,)) # Optional: Keep logs or delete? usually keep logs but nullify user_id
    conn.commit()
    conn.close()

def update_user(user_id, new_name):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE users SET name = ? WHERE id = ?", (new_name, user_id))
    conn.commit()
    conn.close()

def log_event(user_id, user_name, event_type, source='', snapshot_path=''):
    # Use accurate local time string
    local_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT INTO logs (user_id, user_name, event_type, source, snapshot_path, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
              (user_id, user_name, event_type, source, snapshot_path, local_time))
    conn.commit()
    conn.close()

def get_local_time():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def get_logs(limit=50, page=1, per_page=25):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # Get total count
    c.execute("SELECT COUNT(*) FROM logs")
    total = c.fetchone()[0]

    offset = (page - 1) * per_page
    c.execute("SELECT * FROM logs ORDER BY timestamp DESC LIMIT ? OFFSET ?", (per_page, offset))
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows], total

def search_logs(query=None, start_date=None, end_date=None, event_type=None, page=1, per_page=25):
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    where = "WHERE 1=1"
    params = []

    if query:
        where += " AND (user_name LIKE ? OR event_type LIKE ? OR source LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])

    if event_type and event_type != 'all':
        where += " AND event_type = ?"
        params.append(event_type)

    if start_date:
        where += " AND timestamp >= ?"
        params.append(start_date)

    if end_date:
        where += " AND timestamp <= ?"
        params.append(end_date + " 23:59:59")

    # Get total count matching filters
    c.execute(f"SELECT COUNT(*) FROM logs {where}", params)
    total = c.fetchone()[0]

    # Get paginated results
    offset = (page - 1) * per_page
    c.execute(f"SELECT * FROM logs {where} ORDER BY timestamp DESC LIMIT ? OFFSET ?", params + [per_page, offset])
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows], total

def search_logs_all(query=None, start_date=None, end_date=None, event_type=None):
    """Return ALL matching logs (no pagination) - used for CSV export"""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    sql = "SELECT * FROM logs WHERE 1=1"
    params = []

    if query:
        sql += " AND (user_name LIKE ? OR event_type LIKE ? OR source LIKE ?)"
        params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])

    if event_type and event_type != 'all':
        sql += " AND event_type = ?"
        params.append(event_type)

    if start_date:
        sql += " AND timestamp >= ?"
        params.append(start_date)

    if end_date:
        sql += " AND timestamp <= ?"
        params.append(end_date + " 23:59:59")

    sql += " ORDER BY timestamp DESC"

    c.execute(sql, params)
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def clear_all_logs():
    """Delete all logs and their snapshot files"""
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    # Find snapshots to delete
    c.execute("SELECT snapshot_path FROM logs WHERE snapshot_path != ''")
    snapshot_paths = [row[0] for row in c.fetchall()]

    c.execute("DELETE FROM logs")
    deleted_count = c.rowcount
    conn.commit()
    conn.close()

    # Remove snapshot files from disk
    removed_files = 0
    for snap_path in snapshot_paths:
        file_path = snap_path.lstrip('/')
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                removed_files += 1
            except OSError:
                pass

    logger.info("Cleared all logs (%d rows, %d snapshot files removed)", deleted_count, removed_files)
    return deleted_count

def purge_old_logs(days=7):
    """Delete logs older than the specified number of days and their snapshot files"""
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()

    # Find snapshots to delete before removing the log rows
    c.execute("SELECT snapshot_path FROM logs WHERE timestamp < ? AND snapshot_path != ''", (cutoff,))
    snapshot_paths = [row[0] for row in c.fetchall()]

    # Delete old log rows
    c.execute("DELETE FROM logs WHERE timestamp < ?", (cutoff,))
    deleted_count = c.rowcount
    conn.commit()
    conn.close()

    # Remove snapshot files from disk
    removed_files = 0
    for snap_path in snapshot_paths:
        # snapshot_path is stored as "/static/snapshots/filename.jpg"
        # Convert to relative filesystem path
        file_path = snap_path.lstrip('/')
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                removed_files += 1
            except OSError:
                pass

    if deleted_count > 0:
        logger.info("Purged %d logs older than %d days (removed %d snapshot files)", deleted_count, days, removed_files)
    return deleted_count

if __name__ == "__main__":
    init_db()
    logger.info("Database initialized.")
