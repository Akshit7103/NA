"""
Configuration Loader for Video Analytics System
Loads settings from config.yaml
"""

import yaml
import os
import logging
import logging.handlers
from typing import Any, Dict

class Config:
    """Configuration manager for the application"""

    def __init__(self, config_file: str = "config.yaml"):
        self.config_file = config_file
        self._config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        if not os.path.exists(self.config_file):
            raise FileNotFoundError(f"Configuration file '{self.config_file}' not found!")

        with open(self.config_file, 'r') as f:
            config = yaml.safe_load(f)

        return config

    def get(self, key_path: str, default=None):
        """
        Get configuration value using dot notation
        Example: config.get('camera.source')
        """
        keys = key_path.split('.')
        value = self._config

        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default

        return value

    def reload(self):
        """Reload configuration from file"""
        self._config = self._load_config()

    # Convenience properties for commonly used settings
    @property
    def camera_source(self):
        return self.get('camera.source', 0)

    @property
    def is_rtsp(self) -> bool:
        """Check if camera source is RTSP stream"""
        source = self.camera_source
        return isinstance(source, str) and source.lower().startswith('rtsp')

    @property
    def reconnect_attempts(self):
        return self.get('camera.reconnect_attempts', 5)

    @property
    def reconnect_delay(self):
        return self.get('camera.reconnect_delay', 5)

    @property
    def frame_skip(self):
        return self.get('camera.frame_skip', 1)

    @property
    def faces_dir(self):
        return self.get('storage.faces_dir', 'data/faces')

    @property
    def db_path(self):
        return self.get('database.path', 'data/database.db')

    @property
    def face_similarity_threshold(self):
        return self.get('detection.face_similarity', 0.5)

    @property
    def log_cooldown(self):
        return self.get('timing.log_cooldown', 30)

    @property
    def phone_alert_cooldown(self):
        return self.get('timing.phone_alert_cooldown', 10)

    @property
    def unauthorized_face_grace(self):
        return self.get('timing.unauthorized_face_grace', 3.0)

    @property
    def unauthorized_no_face_grace(self):
        return self.get('timing.unauthorized_no_face_grace', 15.0)

    @property
    def track_timeout(self):
        return self.get('timing.track_timeout', 5.0)

    @property
    def server_url(self):
        host = self.get('server.host', '0.0.0.0')
        port = self.get('server.port', 5000)
        # 0.0.0.0 means "all interfaces" - for connecting, use localhost
        if host == '0.0.0.0':
            host = 'localhost'
        return f"http://{host}:{port}"


def setup_logging(config: 'Config' = None, name: str = 'video_analytics') -> logging.Logger:
    """Configure logging using config.yaml settings"""
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers
    if logger.handlers:
        return logger

    level_str = 'INFO'
    log_file = 'logs/app.log'
    max_size = 10485760  # 10MB
    backup_count = 5

    if config:
        level_str = config.get('logging.level', 'INFO')
        log_file = config.get('logging.file', 'logs/app.log')
        max_size = config.get('logging.max_size', 10485760)
        backup_count = config.get('logging.backup_count', 5)

    logger.setLevel(getattr(logging, level_str.upper(), logging.INFO))

    formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )

    # Console handler
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    logger.addHandler(console)

    # File handler with rotation
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    file_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=max_size, backupCount=backup_count
    )
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


# Global config instance
_config = None

def get_config(config_file: str = "config.yaml") -> Config:
    """Get or create global config instance"""
    global _config
    if _config is None:
        _config = Config(config_file)
    return _config
